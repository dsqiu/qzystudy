wxGlade: A GUI builder for wxPython/wxWidgets
Version: 0.6.8
License: MIT (see license.txt)

THIS PROGRAM COMES WITH NO WARRANTY


* Requirements:
---------------
Python >= 2.3
wxPython >= 2.6


* Installation:
---------------
If you are reading this file, you already did all the necessary :-)
To start the program, enter ``python wxglade.py'' in your shell


* Documentation:
----------------
There's a short introductory tutorial in the docs/ subdirectory.  In the
examples/ subdirectory are some sample wxGlade apps (in xml format, .wxg file
extension).


* Known Bugs/Issues:
--------------------
- If you have PyXML installed, be sure to use at least version 0.8.1, as
  otherwise you will not be able to generate code and load saved wxg
  files. This seems to be a PyXML bug, see
  http://sourceforge.net/tracker/?func=detail&atid=106473&aid=573011&group_id=6473 

- On Windows, selection tags may not be shown properly in some cases.

- On GTK, if your last operation before exiting is a paste from the clipboard,
  wxGlade exits with a segfault.

- On GTK, menubars give troubles: they produce a lot of Gtk-WARNING and 
  Gtk-FATAL messages and may cause segfaults.

- On GTK, notebooks can cause some Gtk-WARNING messages, but they seem to
  work anyway.


For any kind of question, there's a mailing list at 
    https://lists.sourceforge.net/lists/listinfo/wxglade-general

Enjoy!
Alberto Griggio
